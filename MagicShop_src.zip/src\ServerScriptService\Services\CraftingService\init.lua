local RS = game:GetService("ReplicatedStorage")
local Shared = RS:WaitForChild("Shared")
local Remotes = require(Shared:WaitForChild("RemotesIndex"))

-- Always resolve the *Folder* and its children by WaitForChild
local CraftingFolder = Shared:WaitForChild("Crafting")
local RecipeBook = require(CraftingFolder:WaitForChild("RecipeBook"))

local ServiceLoader = require(script.Parent.Parent.ServiceLoader)
local DataService = ServiceLoader.requireService("DataService")

local CraftingService = {}

function CraftingService.Init()
    print("[CraftingService] Init")
end

function CraftingService.Start()
    print("[CraftingService] Start")
    print("[CraftingService] Connecting to RequestCraft:", Remotes.RequestCraft)

    local ok, err = pcall(function()
        Remotes.RequestCraft.OnServerEvent:Connect(function(player, station, ingredients)
            ingredients = ingredients or {}
            print(("[CraftingService] Craft request from %s -> %s with %d items")
                :format(player.Name, tostring(station), #ingredients))

            -- Convert client format {itemId, qty} to simple string array for resolver
            local ingredientList = {}
            for _, input in ipairs(ingredients) do
                local itemId = input.itemId or input.id
                local qty = input.qty or 1
                -- Add each quantity as separate entries
                for i = 1, qty do
                    table.insert(ingredientList, itemId)
                end
            end

            local seed = DataService:GetAttunementSeed(player)
            local result = RecipeBook.resolve(station, ingredientList, seed)

            if not result or not result.ok then
                Remotes.CraftingState:FireClient(player, "fail", station, (result and result.reason) or "invalid_recipe")
                return
            end

            -- Build needs table if not provided
            local needs = result.needs
            if not needs then
                needs = {}
                for _,id in ipairs(ingredientList) do needs[id] = (needs[id] or 0) + 1 end
            end

            local has = DataService:HasItems(player, needs)
            if not has then
                local missing = {}
                local pdata = DataService:Get(player)
                for itemId, reqQty in pairs(needs) do
                    local have = (pdata.inventory[itemId] or 0)
                    if have < reqQty then
                        table.insert(missing, itemId)
                    end
                end
                local missingList = table.concat(missing, ", ")
                Remotes.CraftingState:FireClient(player, "fail", result.id, "missing:"..missingList)
                return
            end

            -- stability roll
            if math.random() > (result.stability or 0.85) then
                DataService:ConsumeItems(player, needs) -- design choice: consume on failure
                Remotes.CraftingState:FireClient(player, "fail", result.id, "unstable_reaction")
                return
            end

            DataService:ConsumeItems(player, needs)
            for giveId, qty in pairs(result.gives) do
                DataService:AddItem(player, giveId, qty)
            end

            Remotes.CraftingState:FireClient(player, "success", result.id, result.tier)
            Remotes.CraftedToast:FireClient(player, result.id)
        end)

        Remotes.ToggleCrafting.OnServerEvent:Connect(function(player, isOpen)
            Remotes.CraftingState:FireClient(player, isOpen and "open" or "close")
        end)
    end)

    if not ok then
        warn("[CraftingService] Failed to connect to remotes:", err)
    else
        print("[CraftingService] Remote handlers connected successfully")
    end
end

return CraftingService