-- Lightweight sanity checks at startup
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Ingredients = require(ReplicatedStorage.Shared.Crafting.IngredientDB)
local Effects     = require(ReplicatedStorage.Shared.Crafting.EffectsDB)
local Named       = require(ReplicatedStorage.Shared.Crafting.RecipesDB)

local function canonicalKey(ids)
    table.sort(ids)
    return table.concat(ids, "+")
end

local function splitKey(key)
    local t = {}
    for part in string.gmatch(key, "([^%+]+)") do table.insert(t, part) end
    return t
end

local seen = {}
for station, dict in pairs(Named) do
    for key, recipe in pairs(dict) do
        -- canonical key check
        local ids = splitKey(key)
        local canonical = canonicalKey(table.clone(ids))
        if canonical ~= key then
            warn(("[RecipeValidator] %s key '%s' is not canonical; should be '%s'"):format(station, key, canonical))
        end
        -- ingredient existence
        for _,id in ipairs(ids) do
            if not Ingredients[id] then
                warn(("[RecipeValidator] %s recipe '%s' references missing ingredient '%s'"):format(station, recipe.id, id))
            end
        end
        -- effect existence
        if recipe.effect and not Effects[recipe.effect] then
            warn(("[RecipeValidator] %s recipe '%s' effect '%s' not in EffectsDB"):format(station, recipe.id, tostring(recipe.effect)))
        end
        -- duplicate key detection
        local dupKey = station.."|"..key
        if seen[dupKey] then
            warn(("[RecipeValidator] Duplicate recipe key for %s: %s"):format(station, key))
        else
            seen[dupKey] = true
        end
    end
end

print(("[RecipeValidator] OK: %d stations, %d total named recipes")
    :format(#(function() local c=0 for _ in pairs(Named) do c+=1 end return {1,2,3,4,5,c}[6] end)(), (function()
        local n=0 for _,d in pairs(Named) do for _ in pairs(d) do n+=1 end end return n end)()))
return true