local RS = game:GetService("ReplicatedStorage")
local Remotes = require(RS.Shared.RemotesIndex)
local ServiceLoader = require(script.Parent.Parent.ServiceLoader)
local DataService = ServiceLoader.requireService("DataService")

local DisplayCaseService = {}
DisplayCaseService.Listings = {} -- { [userId] = { {item="", qty=1, price=10}, ... } }

local HttpService = game:GetService("HttpService")
local function uid(plr) return plr.UserId end

function DisplayCaseService:SendDisplayCase(player)
    local listings = self.Listings[player.UserId] or {}
    Remotes.DisplayCaseUpdated:FireClient(player, player.UserId, listings)
end

function DisplayCaseService:GetDisplayCaseData(player)
    return self.Listings[player.UserId] or {}
end

function DisplayCaseService:Init()
    print("[DisplayCaseService] Init")
end

function DisplayCaseService:Start()
    print("[DisplayCaseService] Start")
    -- Handle display case requests
    Remotes.DisplayCaseRequest.OnServerEvent:Connect(function(player, action, payload)
        if action == "GET" then
            -- Send current display case data
            self:SendDisplayCase(player)
        elseif action == "LIST" then
            -- New authoritative listing system
            if type(payload) ~= "table" then
                warn(("[DisplayCaseService] LIST requires payload table from %s"):format(player.Name))
                return
            end
            
            local item, qty, price = payload.item or payload.itemId, payload.qty, payload.price
            if type(item) ~= "string" or type(qty) ~= "number" or type(price) ~= "number" then
                warn(("[DisplayCaseService] Invalid LIST payload from %s: item=%s, qty=%s, price=%s"):format(
                    player.Name, tostring(item), tostring(qty), tostring(price)))
                return
            end

            -- Verify & consume items
            local ok = DataService:HasItems(player, {[item] = qty})
            if not ok then
                print(("[DisplayCaseService] %s doesn't have %s x%d to list"):format(player.Name, item, qty))
                -- Send current listings back (no change)
                Remotes.DisplayCaseUpdated:FireClient(player, player.UserId, self.Listings[player.UserId] or {})
                return
            end

            DataService:ConsumeItems(player, {[item] = qty})

            local uid = player.UserId
            self.Listings[uid] = self.Listings[uid] or {}
            local listingId = HttpService:GenerateGUID(false)
            table.insert(self.Listings[uid], {
                item = item, 
                itemId = item, -- For compatibility
                qty = qty, 
                price = price,
                listingId = listingId
            })

            print(("[DisplayCaseService] %s listed %s x%d for %d¤"):format(player.Name, item, qty, price))
            
            -- Broadcast new list to the owner
            Remotes.DisplayCaseUpdated:FireClient(player, uid, self.Listings[uid])
            
        elseif action == "REMOVE" then
            -- Remove a listing (payload should contain listingIndex or similar)
            print(("[DisplayCaseService] %s requested REMOVE - not yet implemented"):format(player.Name))
            warn("[DisplayCaseService] REMOVE action not yet implemented")
        else
            warn(("[DisplayCaseService] Unknown action '%s' from %s"):format(tostring(action), player.Name))
        end
    end)
end

return DisplayCaseService