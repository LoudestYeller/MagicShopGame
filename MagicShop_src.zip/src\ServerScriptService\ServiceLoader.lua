local SSS = game:GetService("ServerScriptService")
local ServicesFolder = SSS:WaitForChild("Services")

local function moduleFor(name: string)
    local node = ServicesFolder:WaitForChild(name)
    if node:IsA("ModuleScript") then return node end
    -- Folder service: prefer a child ModuleScript named "init", or any ModuleScript
    local init = node:FindFirstChild("init")
    if init and init:IsA("ModuleScript") then return init end
    local any = node:FindFirstChildWhichIsA("ModuleScript")
    assert(any, ("Service %s missing ModuleScript"):format(name))
    return any
end

local function requireService(name: string)
    local ok, result = pcall(function()
        return require(moduleFor(name))
    end)
    if not ok then
        warn(("[ServiceLoader] Failed to require %s: %s"):format(name, result))
        return nil
    end
    return result
end

local order = {
    "DataService","InventoryService","CraftingService",
    "DisplayCaseService","NPCSalesService","TutorialService","DevService"
}

local ServiceLoader = {}
ServiceLoader.requireService = requireService

function ServiceLoader.InitAll()
    for _,n in ipairs(order) do
        local s = requireService(n)
        if s and s.Init then
            local ok, err = pcall(s.Init, s)
            if not ok then warn(("[ServiceLoader] Init failed for %s: %s"):format(n, err)) end
        end
    end
end

function ServiceLoader.StartAll()
    for _,n in ipairs(order) do
        local s = requireService(n)
        if s and s.Start then
            local ok, err = pcall(s.Start, s)
            if not ok then warn(("[ServiceLoader] Start failed for %s: %s"):format(n, err)) end
        end
    end
end

return ServiceLoader